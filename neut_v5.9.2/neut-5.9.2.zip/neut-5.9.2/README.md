# NEUT

### Setup prequisitings

The configure step expects to be able to find `root-config`.

CERNLIB is also required, see below for options.

### CERNLIB

#### CERNLIB 2005

The existence of the following files will be checked at the configure step if `${CERN_LEVEL} -ge 2022` evaluates to false.

```bash
${CERN}/${CERN_LEVEL}/bin/cernlib
${CERN}/${CERN_LEVEL}/include/pdf804/pilot.h
```

For this version of NEUT, we recommend using the Builtin CERNLIB option.

#### Modern CERNLIB

CERNLIB was ressurected and given a new CMake build system in 2022.

The existence of the following files will be checked at the configure step if `${CERN_LEVEL} -ge 2022` evaluates to true.

```bash
${CERN}/bin/cernlib
${CERN}/include/pdf/pilot.h
```

If you do want to prebuild your own modern CERNLIB. Set the `CERN` environment variable to the install prefix.
For modern CERNLIB, built with CMake,`CERN_LEVEL` is not used as part of the assumed CERNLIB prefix.

For this version of NEUT, however, we recommend using the Builtin CERNLIB option.

#### Builtin CERNLIB

The configure option `--enable-builtin-cernlib` will attempt to fetch and build
CERNLIB 2023.08.14.0-free as part of the neut build. It will take 20 minutes
to build with a single core.

This will download and extract a tarball of CERNLIB into /tmp. If the build
completes successfully then it will be removed, but if the build fails it
may be left there.

If you want to use some more cores for building cernlib, use the `CERNLIB_NJOBS`
environment variable like: `CERNLIB_NJOBS="-j $(nproc)" make`. This can be
combined with multicore build for the rest of NEUT like:
`CERNLIB_NJOBS="-j $(nproc)" make -j $(nproc)`. Because everything in NEUT depends
on CERNLIB, this will still use a maximum of `nproc` cores, even though it is specified
twice. CERNLIB built with 8 processors takes just a few minutes.

`motif` is required for compilation. Missing `motif` will manifest as `CMake` errors mentioning `motif`. If you see this, you can find `motif` on Ubuntu in `libmotif-dev`, i.e. through `apt install libmotif-dev`. If you're on RHEL, `yum install openmotif`.

### Configure and build
```
cd /path/to/neut
git submodule update --init
mkdir build; cd build;
../src/configure --prefix=$(readlink -f Linux) --enable-builtin-cernlib
make -j 8
make install
```

*N.B.* If you get autotools whinging about missing LIBTOOL or AM_CONDITIONAL macros, try:

```
cd /path/to/neut
git submodule update --init
cd src
rm aclocal.m4
autoreconf -if
cd ../build;
../src/configure --prefix=$(readlink -f Linux)
make -j 8
make install
```

(Generally most autotools problems are solved by running  `autoreconf`)

### Sourcing the NEUT environment
```
source /path/to/neut/build/Linux/setup.sh
```

### How to run NEUT simulation
[Read me](src/neutsmpl/README.md). <br>
Note: The above enviroment setting is required.


### Linking to NEUT

#### Using neut-config
If the environment is set up then `neut-config` should be available. To build and link an app that needs to be able to read neut vectors you could use
```
-I$(neut-config --incdir) -L$(neut-config --libdir) $(neut-config --libs)
```
which might produce compiler/linker flags like:
```
-I/path/to/neut/build/Linux/include -L/path/to/neut/build/Linux/lib -lneutclassUtils -lneutclass
```

#### Using NEUTConfig.cmake
Make sure that the NEUT_ROOT environment variable is defined and `ls $NEUT_ROOT/cmake` shows `NEUTConfig.cmake`.

In your cmake script run:
```
find_package(NEUT)
```

## When you found issues or bugs in the existing code
Please do not commit to the master.<br>
There is a branch for the next version and bug fix release.<br>
Please use those branches to commit fixes.<br>
(If there are not, please let us know.)<br>

## When you try to implement a new model
Please make a branch to start including a new model implementation.<br>
Make a new directory under src for your new model.<br>
Try to minimize the changes in the existing part.<br>

## Contact
Hayato-san: hayato@icrr.u-tokyo.ac.jp<br>
Luke Pickering: luke.pickering@stfc.ac.uk<br>
Clarence Wret: clarence.wret@physics.ox.ac.uk<br>
Seisho Abe: seisho@km.icrr.u-tokyo.ac.jp <br>
