C------------------------------------------------
C Constant parametrs for DCC
C------------------------------------------------
      real*8 fnuc,fpio,flepi,flepf,pidbl,gf,vud,flepm(0:3),fmw,fmz,wmin

      common / dcc_const /fnuc,fpio,flepi,flepf,pidbl,
     $                    gf,vud,flepm,fmw,fmz, wmin

      real*8 elmin, elmx1, elmx2

      parameter (elmin = 0.0d0)
      parameter (elmx1 = 5.0d0)
      parameter (elmx2 = 30.d0)

      integer*4 mxel1,mxel2, mxel
      parameter (mxel1 = 500)
      parameter (mxel2 = 250)
c--   mxel = mxel1 + mxel2      
      parameter (mxel  = 750)

      real*8 min_dcc_totcrs
      parameter (min_dcc_totcrs=1.e-5)

C---------------------------------------
