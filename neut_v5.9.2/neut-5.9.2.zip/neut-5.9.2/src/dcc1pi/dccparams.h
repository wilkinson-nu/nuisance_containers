C------------------------------------------------
C loaded parameters and cross-sections for DCC
C------------------------------------------------
      integer*4 maxwcm, maxq2
      parameter(maxwcm=150,maxq2=50)

      real*8 
     $     wcmdat_all(3,maxwcm),
     $     q2dat_all(3,maxq2),
     &     walldat_all(3,5,2,maxwcm,maxq2),
     $     wpidat_all(3,5,2,maxwcm,maxq2),
     &     wpicdat_all(3,5,4,maxwcm,maxq2)

      common / dcc_cstruc_all / 
     $     wcmdat_all,
     $     q2dat_all,
     &     walldat_all,
     $     wpidat_all,
     &     wpicdat_all,
     $     mxwcm_all,
     $     mxq2_all

C------------------------------------------------
      real*8 
     $     wcminin_all(3),
     $     wcmaxin_all(3),
     $     q2minin_all(3),
     $     q2maxin_all(3)

      common /dcc_cmxwq2_all/ 
     $     wcminin_all,
     $     wcmaxin_all,
     $     q2minin_all,
     $     q2maxin_all

C------------------------------------------------
      real*8 
     $     wcmdat(maxwcm),q2dat(maxq2),
     &     walldat(5,2,maxwcm,maxq2),
     $     wpidat(5,2,maxwcm,maxq2),
     &     wpicdat(5,4,maxwcm,maxq2)

      integer*4 mxwcm,mxwcm_all(3),mxq2,mxq2_all(3)

      common / dcc_cstruc / 
     $     wcmdat,q2dat,
     &     walldat,wpidat,
     &     wpicdat,mxwcm,mxq2

C---------------------------------------
      real*8 wcminin,wcmaxin,q2minin,q2maxin

      common / dcc_cmxwq2/ wcminin,wcmaxin,q2minin,q2maxin

C---------------------------------------
      integer*4 ndim
      parameter(ndim=200)

      real*8 wcal(ndim),weiw(ndim),qcal(ndim,ndim),weiq(ndim,ndim)
      
      integer*4 mxwcal,mxqcal

      common / dcc_calwq  / wcal,weiw,qcal,weiq,mxwcal,mxqcal

C---------------------------------------
      integer*4 ndim_enu
      parameter(ndim_enu=750)

      real*8 wcmcut_totcrs, q2cut_totcrs, dcc_etbl(ndim_enu),
     $     dcc_cc_totcrs_tbl(6,3,ndim_enu),
     $     dcc_nc_totcrs_tbl(2,4,ndim_enu),
     $     dcc_em_totcrs_tbl(4,ndim_enu)
      
      
      common / dcc_totcrs_tbl  / wcmcut_totcrs, q2cut_totcrs, 
     $     dcc_etbl, 
     $     dcc_cc_totcrs_tbl, dcc_nc_totcrs_tbl,
     $     dcc_em_totcrs_tbl

C---------------------------------------
      integer*4 dcc_tbl_loaded
      character*1024 dcc_tbl_path

      common / dcc_tbl_path / dcc_tbl_loaded, dcc_tbl_path
      
