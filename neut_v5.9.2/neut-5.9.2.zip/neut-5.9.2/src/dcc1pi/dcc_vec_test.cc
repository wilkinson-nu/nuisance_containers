#include <TROOT.h>
#include <TFile.h>
#include <TH1D.h>
#include <TH2D.h>
#include <cmath>
#include <iostream>

extern "C" {

  void dcc_vec_(int    * /*nemode*/, 
				int    * /*inlep */,
				double * /*e lep*/, 
				double * /*return p_lep*/,
				double * /*return p_pi */, 
				double * /*return p_nucleon */,
				int    * /* error flag */);
}

double
norm_3d(double vec[3])
{
  double norm_3d;
  norm_3d = std::sqrt(vec[0]*vec[0]+vec[1]*vec[1]+vec[2]*vec[2]);
  return norm_3d;
}


void
vecdiff_3d(double *vec1,double *vec2,double *vec_diff)
{
  /* vec_diff = vec1 - vec2 */

  int i;
  
  for (i = 0; i < 3; i++){
	vec_diff[i] = vec1[i] - vec2[i];
  }
}

void
vecsum_3d(double *vec1,double *vec2,double *vec_sum)
{
  /* vec_sum = vec1 + vec2 */

  int i;
  for (i = 0; i < 3; i++){
	vec_sum[i] = vec1[i] + vec2[i];
  }
}



int
main(int argc, char **argv)
{
  int    nemode;
  int    inlep;
  double e_inlep;

  double p_outlep[3], absp_outlep, e_outlep;
  double p_outpi[3] , absp_outpi,  e_outpi;
  double p_outnuc[3], absp_outnuc, e_outnuc;
  
  double p_tmp[3], absp_tmp;
  double w,q2;

  int    error_flag;

  error_flag = 0;

  TFile *f;
  TH1D *h_out_lmom;
  TH1D *h_out_pimom;
  TH1D *h_resmass;
  TH1D *h_econserv;
  TH1D *h_q2;
  TH2D *h_q2w;

  int i;

  nemode  = 11;  /* nu -> l- p pi+ */
  inlep   = 12;  /* numu */
  e_inlep = 3.0; /* GeV  */

  f = new TFile("output.root","RECREATE");
  f->cd();
  h_out_lmom = new TH1D("out_lmom","Outgoing lepton momentum",
						300,0.,3.);
  h_out_pimom = new TH1D("out_pimom","Outgoing pion momentum",
						300,0.,3.);
  h_resmass   = new TH1D("resmass","Resonance invariant mass",
						100,1.,2.);
  h_econserv  = new TH1D("econserv","Energy conservation(GeV)",
						 100,-0.1,0.1);

  for (i = 0 ; i <100000 ; i++){
	dcc_vec_(&nemode, &inlep, &e_inlep,
			 p_outlep, p_outpi, p_outnuc, &error_flag);
	if (error_flag != 0) continue;
	absp_outlep = norm_3d(p_outlep);
	absp_outpi  = norm_3d(p_outpi);
	absp_outnuc = norm_3d(p_outnuc);

	e_outlep = std::sqrt(absp_outlep * absp_outlep + 0.005*0.005);
	e_outpi  = std::sqrt(absp_outpi  * absp_outpi  + 0.138*0.138);
	e_outnuc = std::sqrt(absp_outnuc * absp_outnuc + 0.939*0.939);

/*
	std::cout << "econserv  " 
			  << e_inlep + 0.939 - e_outlep - e_outpi - e_outnuc
			  << std::endl;
*/

	vecsum_3d(p_outpi, p_outnuc, p_tmp);
	absp_tmp = norm_3d(p_tmp);

	w = (e_outpi + e_outnuc)*(e_outpi + e_outnuc) 
	  - absp_tmp*absp_tmp;
	w = std::sqrt(w);


	h_out_lmom->Fill(absp_outlep);
	h_out_pimom->Fill(absp_outpi);
	h_resmass->Fill(w);
	h_econserv->Fill(e_inlep + 0.939 - e_outlep - e_outpi - e_outnuc);

  }
  
  f->Write();
  f->Close();
  return 0;
}
