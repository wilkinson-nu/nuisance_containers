S.Abe 30th Sep., 2024
- This directory contains SF-based QE Xsec with M_A = 1.21 GeV & g_A^s = -0.08.
- It contains NCQE Xsec only.
- For CCQE, NEUT reads tables in `qelSfData.1.21/`.
  - Because g_A^s affects NC only.
