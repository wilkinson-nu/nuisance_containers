************************************************************************
*     neutparams.h
C
*     define NEUT parameter which is related to the
C     fermi momentum and nuclear potential
C
C---------------------------------------------------------
C
C    PFSURF : Fermi srface momentum
C               in (GeV)
C
C    PFMAX  : Maximum value of the Fermi momentum
C                (usually, this value is same as PFSURF.)
C               in (GeV)
C
C    VNUINI : Nuclear potential (initial state)
C               Negative VALUE (GeV)
C
C    VNUFIN : Nuclear potential (final state)
C               Negative VALUE (GeV)
C
C    SFEBSHIFT: Extra missing energy shift for SF events (GeV)
C                 Positive means more missing energy.
C    SFEBNEGBEH: Behavior if SFEb is below 0 (i.e. chosen nucleon is unbound)
C               0: Pin to EB = 0 and continue event generation
C               1: Redraw from SF (for large negative SFEBShift, will get stuck in infinite loops)
C
C    SFCORRNNFRAC: Fraction of 'other' nucleon in correlated
C                   pair which is the same particle type, i.e. if this is 
C                   set to 0.3 30% of correlated pair events will be NN and 
C                   70% will be the default np
C
C    IFORMLEN: FORMATION LENGTH effect ON/OFF
C              IFORMLEN=   1  : ALL ON 
C              IFORMLEN=   0  : ALL OFF
C              IFORMLEN= 110  : OFF for QE/Elastic (default)
C              IFORMLEN= 100  : ON  for mPi/DIS only
C
C    FZMU2     FORMATION ZONE FREE PARAMETER (SCAT MODEL, DEFAULT 0.08)
C---------------------------------------------------------
C
C    FEFQE  : Correction Factor to the probability (p<500)
C                              of quasielastic scattering ( single pi )
C    FEFQEH : Correction Factor to the probability (p>500)
C                              of quasielastic scattering ( single pi )
C
C    FEFINEL: Correction Factor to the probability (p>500)
C                              of hadron prod. (inel. scatter)
C
C    FEFABS : Correction Factor to the probability (p<500)
C                              of absorption
C
C    FEFCOH : Correction Factor to the probability (p>500)
C                              of coherent(forward)-scattering
C
C    FEFCX  : Correction Factor to the charge exchange amplitude (p<500)
C
C    FEFCXH : Correction Factor to the charge exchange prob. (p>500)
C
C    FEFQEHF: Portion of QE scattering that has isotropic resonance decay
C                              kinematics (p>500)
C
C    FEFCOHF: Amount of forward (elastic) scatter relative
C                              to inelastic (p<500)
C
C    FEFCXHF: Portion of inel. scattering that includes true CX (p>500)
C
C    FEFCOUL: Coulomb correction to pion cascade trajectory (0: default, off)
C
C    FEFALL:  Correction factor to the total mean free path (all momenta)
C
C---------------------------------------------------------
C    FEFSIPAU : ( NEUT-FEFSIPAU ) Flag for nucleon Pauli Blocking in the cascade (Pi and Nuc)
C               0 : on ( default )
C               1 : off
C---------------------------------------------------------
C
      REAL*4 PFSURF,PFMAX,VNUINI,VNUFIN,FZMU2,SFEBSHIFT,SFCORRNNFRAC
      INTEGER*4 IFORMLEN, SFEBNEGBEH

      COMMON/NENUPR/PFSURF,PFMAX,VNUINI,VNUFIN,IFORMLEN,FZMU2,
     $ SFEBSHIFT, SFEBNEGBEH, SFCORRNNFRAC
C
C---------------------------------------------------------
C
      REAL*4 FEFQE,FEFQEH,FEFINEL,FEFABS,FEFCOH,FEFQEHF,FEFCOHF,FEFCX,
     $       FEFCXHF,FEFCXH,FEFCOUL,FEFALL
      INTEGER*4 FEFSIPAU

      COMMON/NEFFPR/FEFQE,FEFQEH,FEFINEL,FEFABS,FEFCOH,FEFQEHF,FEFCOHF,
     $              FEFCX,FEFCXHF,FEFCXH,FEFCOUL,FEFALL,FEFSIPAU
C
C---------------------------------------------------------
C
C     Q2THRES: Minimum Q^2 threshold for event or xsec generation (MeV/c)^2
C     Q3EBS: Turn on(1)/off(0:default) Q3EBSHIFT, f(q3)=a*q3+b (MeV)
C     Q3EBSA, Q3EBSB: Parameters of Q3EBSHIFT (applied if Q3EBS=1)
C     ELECOUL: Coulomb effect on(1:default)/off(0)
C               
      INTEGER*4 USEEMA, Q3EBS, ELECOUL
      REAL*4    Q2THRES, Q3EBSA, Q3EBSB
      COMMON/ELECTRON/Q2THRES, USEEMA, Q3EBS, Q3EBSA, Q3EBSB, ELECOUL
