*******************************************
*       COMMON BLOCK FOR FNELSPAN
*
*
*******************************************

      REAL CRSRFGELNU(2,12,210)
      REAL CRSRFGELAN(2,12,210)

      REAL CRSSFELNU(2,12,210)
      REAL CRSSFELAN(2,12,210)

C --- for electron scattering 
      REAL CRSSFELEL(2,12,210)

      COMMON /NCELCRS/CRSRFGELNU,CRSRFGELAN,CRSSFELNU,CRSSFELAN,CRSSFELEL
