************************************************************************
*     --------
*     NEXSECWEIGHTS.H
*     --------

      REAL   CRSNEUT2,CRSNEUTB2

      COMMON/nexsecweights/CRSNEUT2(30),CRSNEUTB2(30)
      
