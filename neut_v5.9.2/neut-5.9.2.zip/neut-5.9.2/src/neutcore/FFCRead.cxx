// Reimplemented subset of FFREAD-like functionality with reference to
// https://cds.cern.ch/record/2296371/files/ffio.pdf

#include <algorithm>
#include <cctype>
#include <cstring>
#include <fstream>
#include <iostream>
#include <map>
#include <vector>

// #define FFREAD_CXX_DEEP_DEBUG
// #define FFREAD_CXX_VERBOSE

class FFReader;

FFReader *FFReader_inst = nullptr;

class FFReader {

  std::map<std::string, std::string> line_kv_pairs;

  std::map<std::string, std::pair<char *, size_t> > char_fields;
  std::map<std::string, std::pair<int *, size_t> > int_fields;
  std::map<std::string, std::pair<float *, size_t> > float_fields;

  FFReader() {}

public:
  static FFReader &get() {
    if (!FFReader_inst) {
      FFReader_inst = new FFReader();
    }
    return *FFReader_inst;
  }

  void tokenize(std::string filename, std::string bank) {

    std::cout << "Reading bank: " << bank << " from card file: " << filename
              << std::endl;

    std::string bank_prefix = tolower(bank) + "-";

    line_kv_pairs.clear();

    char_fields.clear();
    int_fields.clear();
    float_fields.clear();

    std::string line;
    std::ifstream infile(filename.c_str());
    if (!infile) {
      std::cout << "[ERROR]: Failed to open input file: " << strerror(errno)
                << std::endl;

      abort();
    }
    while (std::getline(infile, line)) {

#ifdef FFREAD_CXX_DEEP_DEBUG
      std::cout << "ln: \"" << line << "\"" << std::endl;
      std::cout << "     1........2........3........4........5........"
                << std::endl;
#endif

      if (!line.size() || (line.front() == 'C') || line.front() == '!') {
        continue;
      }

      // grab key
      size_t key_start = line.find_first_not_of(' ');

      if (key_start != 0) {
        line = line.substr(key_start);
      }

      size_t key_end = line.find_first_of(' ');

#ifdef FFREAD_CXX_DEEP_DEBUG
      std::cout << "  key_start = " << key_start << ", key_end = " << key_end
                << std::endl;
#endif

      std::string key_lower = tolower(line.substr(0, key_end));

      if (key_lower.find(bank_prefix) != 0) {
#ifdef FFREAD_CXX_DEEP_DEBUG
        std::cout << "key: " << key_lower << " not in bank: " << bank
                  << std::endl;
#endif
        continue;
      }

      std::string bank_stripped_key = key_lower.substr(bank_prefix.size());

      line_kv_pairs[bank_stripped_key] = line.substr(key_end + 1);
#ifdef FFREAD_CXX_VERBOSE
      std::cout << "  key: \"" << bank_stripped_key << "\", value: \""
                << line.substr(key_end + 1) << "\"" << std::endl;
#endif
    }
  }

  std::string tolower(std::string keys) {
    std::transform(keys.begin(), keys.end(), keys.begin(),
                   [](char c) { return std::tolower(c); });
    return keys;
  }

  bool has_key(std::string key) { return line_kv_pairs.count(key); }

  void register_CHAR(std::string key, void *data, int number) {
    key = tolower(key);

    if (!has_key(key)) {
#ifdef FFREAD_CXX_VERBOSE
      std::cout << "   Not registering unknown key: " << key << std::endl;
#endif
      return;
    }
#ifdef FFREAD_CXX_VERBOSE
    std::cout << "+  Registering CHAR key: " << key << ", addr: " << data
              << ", " << number << " entries." << std::endl;
#endif
    char_fields[tolower(key)] =
        std::pair<char *, int>(static_cast<char *>(data), number);
  }

  void register_INTEGER(std::string key, void *data, int number) {
    key = tolower(key);
    if (!has_key(key)) {
#ifdef FFREAD_CXX_DEEP_DEBUG
      std::cout << "   Not registering unknown key: " << key << std::endl;
#endif
      return;
    }
#ifdef FFREAD_CXX_VERBOSE
    std::cout << "+  Registering INTEGER key: " << key << ", addr: " << data
              << ", " << number << " entries." << std::endl;
#endif
    int_fields[tolower(key)] =
        std::pair<int *, int>(static_cast<int *>(data), number);
  }

  void register_REAL(std::string key, void *data, int number) {
    key = tolower(key);

    if (!has_key(key)) {
#ifdef FFREAD_CXX_DEEP_DEBUG
      std::cout << "   Not registering unknown key: " << key << std::endl;
#endif
      return;
    }
#ifdef FFREAD_CXX_VERBOSE
    std::cout << "+  Registering REAL key: " << key << ", addr: " << data
              << ", " << number << " entries." << std::endl;
#endif
    float_fields[tolower(key)] =
        std::pair<float *, int>(static_cast<float *>(data), number);
  }

  void read_CHAR(std::string field, char *data, size_t number) {
    size_t string_start = field.find_first_of('\'');
    size_t string_end = field.find_first_of('\'', string_start + 1);

    std::fill_n(data, number,
                ' '); // FORTRAN convention is filling it with spaces

    size_t strlen = std::min(string_end - (string_start + 1), number);

    std::string str = field.substr(string_start + 1, strlen);

    std::copy_n(str.begin(), strlen, data);

#ifdef FFREAD_CXX_VERBOSE
    std::cout << "Read value: \"" << str << "\", len: " << strlen
              << " from: " << field << std::endl;
#endif
  }

  std::vector<std::string> split(std::string original_field) {
    std::vector<std::string> splits;

    std::string field = original_field;

    size_t first_not_space = field.find_first_not_of(' ');

#ifdef FFREAD_CXX_DEEP_DEBUG
    std::cout << "split(" << field << ")" << std::endl;
#endif

    while (first_not_space != std::string::npos) {
      size_t first_space = field.find_first_of(' ', first_not_space);

      if (first_space == std::string::npos) {
        std::string element = field.substr(first_not_space);
#ifdef FFREAD_CXX_DEEP_DEBUG
        std::cout << "  > element: \"" << element
                  << "\", len: " << element.size() << std::endl;
#endif
        splits.push_back(element);
        break;
      }

#ifdef FFREAD_CXX_DEEP_DEBUG
      std::cout << "  - field: \"" << field << "\"" << std::endl;
      std::cout << "  first not space @ " << first_not_space << std::endl;
      std::cout << "  first space after @ " << first_space << std::endl;
#endif

      std::string element =
          field.substr(first_not_space, first_space - first_not_space);

#ifdef FFREAD_CXX_DEEP_DEBUG
      std::cout << "  > element: \"" << element
                << "\", len: " << (first_space - first_not_space) << std::endl;
#endif

      splits.push_back(element);
      field = field.substr(first_space + 1);

      first_not_space = field.find_first_not_of(' ');
    }

#ifdef FFREAD_CXX_DEEP_DEBUG
    std::cout << "Split field: \"" << original_field
              << "\" into: " << std::endl;
    for (auto f : splits) {
      std::cout << "\t" << f << std::endl;
    }
#endif

    return splits;
  }

  void read_INTEGER(std::string field, int *data, size_t number) {
    auto splits = split(field);

    for (size_t i = 0; i < std::min(number, splits.size()); ++i) {
      data[i] = std::stoi(splits[i]);
    }
  }

  void read_REAL(std::string field, float *data, size_t number) {
    auto splits = split(field);

    for (size_t i = 0; i < std::min(number, splits.size()); ++i) {
      data[i] = std::stof(splits[i]);
    }
  }

  void go() {
    for (auto &cf : char_fields) {
      read_CHAR(line_kv_pairs[cf.first], cf.second.first, cf.second.second);
    }
    for (auto &intf : int_fields) {
      read_INTEGER(line_kv_pairs[intf.first], intf.second.first,
                   intf.second.second);
    }
    for (auto &ff : float_fields) {
      read_REAL(line_kv_pairs[ff.first], ff.second.first, ff.second.second);
    }
  }
};

std::string f2cstr(char const *filename, int len) {
  std::vector<char> arr;

  std::copy_n(filename, len, std::back_inserter(arr));
  arr.push_back('\0');

  std::string cstr = arr.data();
  cstr = cstr.substr(0, cstr.find_first_of(' '));
#ifdef FFREAD_CXX_DEEP_DEBUG
  std::cout << "f2cstr:: len(in) = " << len << ", cstr: \"" << cstr
            << "\", len: " << cstr.size() << std::endl;
#endif
  return cstr;
}

#if __GNUC__ > 7
typedef size_t fortran_charlen_t;
#else
typedef int fortran_charlen_t;
#endif

extern "C" {

void ffcinit_(char const *filename, char const *bank,
              fortran_charlen_t filename_len, fortran_charlen_t bank_len) {
  FFReader::get().tokenize(f2cstr(filename, filename_len),
                           f2cstr(bank, bank_len));
}
void ffckey_integer_(char const *key, void *data, int *number,
                     fortran_charlen_t key_len) {
  FFReader::get().register_INTEGER(f2cstr(key, key_len), data, (*number));
}
void ffckey_real_(char const *key, void *data, int *number,
                  fortran_charlen_t key_len) {
  FFReader::get().register_REAL(f2cstr(key, key_len), data, (*number));
}
void ffckey_char_(char const *key, void *data, int *number,
                  fortran_charlen_t key_len) {
  FFReader::get().register_CHAR(f2cstr(key, key_len), data, (*number));
}

void ffcgo_() { FFReader::get().go(); }
}