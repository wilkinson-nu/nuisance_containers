# How to run NEUT simulation
- Creation Date and Authour
  - 2023.05 ; S. Abe ; Draft

## Index
[[_TOC_]]

## How to simulate neutrino interaaction

### Make ROOT file
```
neutroot2 [INPUT CARD] [OUPUT ROOT FILE]
```
- [PROGMRAM]
  - `./neutroot.F`
- [INPUT CARD]
  - Example cards are in `./Cards`
  - See [another readme](./README.CARD) for details.
- [OUTPUT ROOT FILE]
  - `neuttree` (TTree) will be stored.

### Check parameters in ROOT file
```
root './chkreadneutroot.cc("[INPUT ROOT FILE]")'
```
- [PROGRAM]
  - `./chkreadneutroot.cc`
  - ROOT macro.
- [INPUT ROOT FILE]
  - Specify the ROOT file created in the previous process.

## How to check cross section tables

### Make ROOT file
```
cross_section_histos [INPUT CARD] [OUTPUT ROOT FILE]
```
- [PROGMRAM]
  - `./cross_section_histos.cc`
- [OUTPUT ROOT FILE]
  - `crssect` (TTree), which contains neutrino energy (float) and cross sections (float 2D array), will be stored.
  - UNIT: cross section per nucleon

### Read ROOT file 
```
root './plot_cross_section.C("[INPUT ROOT FILE]")'
```
- [PROGRAM]
  - `./plot_cross_section.C`
  - ROOT macro.
  - NOTE: Please check following parameters before execution.
    - `int num_of_nucleon, num_of_n, num_of_p, num_of_free_p`
- [INPUT ROOT FILE]
  - Specify the ROOT file created in the previous process.
