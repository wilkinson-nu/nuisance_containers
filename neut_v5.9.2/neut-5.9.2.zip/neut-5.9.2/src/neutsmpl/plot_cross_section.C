// ---------------------------------------------- // 
// Read cross section root file and 
//  
//  (Input): fname
//    Root file <- Needs to be created by cross_section_histos
//    The unit of cross section stored in the Root file is [ 10^-38 cm^2 / nucleon ]
//    
//  (Output): TGraph & TCanvas
//    The number of nucleon is multiplied.
//
//  (Note) 
//    Make sure the parameters below agree with what you want to check
//      int num_of_nucleon, num_of_n, num_of_p, num_of_free_p
//  
//  (Creating Date and Author)
//    2023.05 ; S.Abe  ; Share Abe's code.

#include <sstream> 
#include <fstream> 

int plot_cross_section(char* fname){
    //- ----FIXME ----- //
    const int flag=1;
    // 0 -> H2O
    // 1 -> O
    //- --------------- //
    
    std::ostringstream os, target;
    target.str("");
    int num_of_nucleon, num_of_n, num_of_p, num_of_free_p;
    if(flag==0){
      num_of_n=8;
      num_of_p=8;
      num_of_free_p=2;
      target << "H2O";
    }else if(flag==1){
      num_of_n=8;
      num_of_p=8;
      num_of_free_p=0;
      target << "O";
    }else abort();
    num_of_nucleon=num_of_n + num_of_p + num_of_free_p;


    TFile* rootf = new TFile(fname,"READ");
    TTree* tree = (TTree*) rootf->Get("crssect");
    
    Float_t enu;
    Float_t crssect[6][60];

    tree->SetBranchAddress("enu",&enu);
    tree->SetBranchAddress("crssect",&crssect);

    
    const char* nuname[]={"#nu_{e}","#nu_{#mu}","#nu_{#tau}","#bar{#nu}_{e}","#bar{#nu}_{#mu}","#bar{#nu}_{#tau}"};
    //  [0] -> 12
    //  [1] -> 14
    //  [2] -> 16 
    //  [3] -> -12 
    //  [4] -> -14
    //  [5] -> -16 

    TGraph* e_c[6]; // total
    TGraph* e_c_cc[6]; // CC total
    TGraph* e_c_nc[6]; // NC total
    TGraph* e_c_ccqe[6];
    TGraph* e_c_ccmec[6];
    TGraph* e_c_cc1pi[6];
    TGraph* e_c_cccoh[6];
    TGraph* e_c_ccgamma[6];
    TGraph* e_c_ccmpi[6];
    TGraph* e_c_ccdis[6];
    TGraph* e_c_nc1pi[6];
    TGraph* e_c_nccoh[6];
    TGraph* e_c_ncgamma[6];
    TGraph* e_c_ncmpi[6];
    TGraph* e_c_ncdis[6];
    TGraph* e_c_ncel[6];
    TGraph* e_c_ncel_p[6];
    TGraph* e_c_ncel_n[6];
    // r_
    TGraph* r_e_c[6]; // total
    TGraph* r_e_c_cc[6]; //CC  total
    TGraph* r_e_c_nc[6]; //NC  total
    TGraph* r_e_c_ccqe[6];
    TGraph* r_e_c_ccmec[6];
    TGraph* r_e_c_cc1pi[6];
    TGraph* r_e_c_cccoh[6];
    TGraph* r_e_c_ccgamma[6];
    TGraph* r_e_c_ccmpi[6];
    TGraph* r_e_c_ccdis[6];
    TGraph* r_e_c_nc1pi[6];
    TGraph* r_e_c_nccoh[6];
    TGraph* r_e_c_ncgamma[6];
    TGraph* r_e_c_ncmpi[6];
    TGraph* r_e_c_ncdis[6];
    TGraph* r_e_c_ncel[6];
    TGraph* r_e_c_ncel_p[6];
    TGraph* r_e_c_ncel_n[6];
    //
    Int_t index[6];
    // for CS
    Float_t crs[6][60]={0.0};
    Float_t r_crs[6][60]={0.0};
    for(int j=0;j<6;j++){
        e_c[j] = new TGraph;
        e_c_cc[j] = new TGraph;
        e_c_nc[j] = new TGraph;
        e_c_ccqe[j] = new TGraph;
        e_c_ccmec[j] = new TGraph;
        e_c_cc1pi[j] = new TGraph;
        e_c_cccoh[j] = new TGraph;
        e_c_ccgamma[j] = new TGraph;
        e_c_ccmpi[j] = new TGraph;
        e_c_ccdis[j] = new TGraph;
        e_c_nc1pi[j] = new TGraph;
        e_c_nccoh[j] = new TGraph;
        e_c_ncgamma[j] = new TGraph;
        e_c_ncmpi[j] = new TGraph;
        e_c_ncdis[j] = new TGraph;
        e_c_ncel[j] = new TGraph;
        e_c_ncel_p[j] = new TGraph;
        e_c_ncel_n[j] = new TGraph;
        // r_
        r_e_c[j] = new TGraph;
        r_e_c_cc[j] = new TGraph;
        r_e_c_nc[j] = new TGraph;
        r_e_c_ccqe[j] = new TGraph;
        r_e_c_ccmec[j] = new TGraph;
        r_e_c_cc1pi[j] = new TGraph;
        r_e_c_cccoh[j] = new TGraph;
        r_e_c_ccgamma[j] = new TGraph;
        r_e_c_ccmpi[j] = new TGraph;
        r_e_c_ccdis[j] = new TGraph;
        r_e_c_nc1pi[j] = new TGraph;
        r_e_c_nccoh[j] = new TGraph;
        r_e_c_ncgamma[j] = new TGraph;
        r_e_c_ncmpi[j] = new TGraph;
        r_e_c_ncdis[j] = new TGraph;
        r_e_c_ncel[j] = new TGraph;
        r_e_c_ncel_p[j] = new TGraph;
        r_e_c_ncel_n[j] = new TGraph;
        //
        index[j]=0;
        for(int i=0;i<tree->GetEntries();i++){
            tree->GetEntry(i);
            // multiply by target
            crs[j][0]  = crssect[j][0]*num_of_nucleon;

            crs[j][2]  = crssect[j][2]*num_of_nucleon;  // NEU,N+X -> LEP-,P+X (X=N OR P)
            crs[j][16] = crssect[j][16]; // NEU,C -> LEP-,C,PI+  (coherent)
            crs[j][21] = crssect[j][21]*num_of_nucleon; // NEU,(N OR P) -> LEP-,(N OR P),MESONS (1.3<W<2.0GeV)
            crs[j][26] = crssect[j][26]*num_of_nucleon; // NEU,(N OR P) -> LEP-,(N OR P),MESONS (DIS)(W>2.0GeV)
            crs[j][36] = crssect[j][36]; // NEU,C -> NEU,C,PI0  (coherent)
            crs[j][41] = crssect[j][41]*num_of_nucleon; // NEU,(N OR P) -> NEU,(N OR P),MESONS (1.3GeV<W<2.0GeV)
            crs[j][46] = crssect[j][46]*num_of_nucleon; // NEU,(N OR P) -> NEU,(N OR P),MESONS (DIS)(W>2.0GeV)
        
            if(j<=2){ // neutrino
                // CC
                crs[j][1]  = crssect[j][1]*num_of_n;  // NEU,N -> LEP-,P
                crs[j][11] = crssect[j][11]*num_of_p; // NEU,P -> LEP-,P,PI+
                crs[j][12] = crssect[j][12]*num_of_n; // NEU,N -> LEP-,P,PI0
                crs[j][13] = crssect[j][13]*num_of_n; // NEU,N -> LEP-,N,PI+
                crs[j][14] = crs[j][11]+crs[j][12]+crs[j][13]; // CC1pi
                crs[j][17] = crssect[j][17]*num_of_n; // NEU,N -> LEP-,P,GAMMA
                // NC
                crs[j][31] = crssect[j][31]*num_of_n; // NEU,N -> NEU,N,PI0
                crs[j][32] = crssect[j][32]*num_of_p; // NEU,P -> NEU,P,PI0
                crs[j][33] = crssect[j][33]*num_of_n; // NEU,N -> NEU,P,PI-
                crs[j][34] = crssect[j][34]*num_of_p; // NEU,P -> NEU,N,PI+
                crs[j][30] = crs[j][31]+crs[j][32]+crs[j][33]+crs[j][34]; // NC1pi
                crs[j][38] = crssect[j][38]*num_of_n; // NEU,N -> NEU,N,GAMMA
                crs[j][39] = crssect[j][39]*num_of_p; // NEU,P -> NEU,P,GAMMA
                crs[j][40] = crs[j][38]+crs[j][39]; // NCgamma
                crs[j][51] = crssect[j][51]*num_of_p; // NEU,P -> NEU,P
                crs[j][52] = crssect[j][52]*num_of_n; // NEU,N -> NEU,N
                crs[j][53] = crs[j][51]+crs[j][52]; // NCEL

                //std::cout << crssect[j][20] << std::endl;

                // [58] -> CCTOT
                crs[j][58] = crs[j][1]+crs[j][2]+crs[j][14]+crs[j][16]+crs[j][17] // QE, MEC, 1PI, COH, 1gamma
                                 //+ crssect[j][18]*num_of_n + crssect[j][19]*num_of_n + crssect[j][20]*num_of_n // 1K// These are invalid
                                 + crs[j][21] + crssect[j][22]*num_of_n + crssect[j][23]*num_of_n // MPI, 1ETA, 1K
                                 + crs[j][26]; // DIS
                // [59] -> NCTOT
                crs[j][59] = crs[j][30] + crs[j][36] + crs[j][40] + crs[j][41]  // 1PI, COH, 1gamma, MPI
                                + crssect[j][42]*num_of_n + crssect[j][43]*num_of_p // 1ETA
                                + crssect[j][44]*num_of_n + crssect[j][45]*num_of_p // 1K
                                + crs[j][46] + crs[j][53]; // DIS, EL
            }
            else{// antineutrino
                // CC
                crs[j][1]  = crssect[j][1]*num_of_p;  // NEUBAR,P -> LEP+,N
                crs[j][11] = crssect[j][11]*num_of_n; // NEUBAR,N -> LEP+,N,PI-
                crs[j][12] = crssect[j][12]*num_of_p; // NEUBAR,P -> LEP+,N,PI0
                crs[j][13] = crssect[j][13]*num_of_p; // NEUBAR,P -> LEP+,P,PI-
                crs[j][14] = crs[j][11]+crs[j][12]+crs[j][13]; // CC1pi
                crs[j][17] = crssect[j][17]*num_of_p; // NEUBAR,P -> LEP+,N,GAMMA
                // NC
                crs[j][31] = crssect[j][31]*num_of_n; // NEUBAR,N -> NEUBAR,N,PI0
                crs[j][32] = crssect[j][32]*num_of_p; // NEUBAR,P -> NEUBAR,P,PI0
                crs[j][33] = crssect[j][33]*num_of_n; // NEUBAR,N -> NEUBAR,P,PI-
                crs[j][34] = crssect[j][34]*num_of_p; // NEUBAR,P -> NEUBAR,N,PI+
                crs[j][30] = crs[j][31]+crs[j][32]+crs[j][33]+crs[j][34]; // NC1pi
                crs[j][38] = crssect[j][38]*num_of_n; // NEUBAR,N -> NEUBAR,N,GAMMA
                crs[j][39] = crssect[j][39]*num_of_p; // NEUBAR,P -> NEUBAR,P,GAMMA
                crs[j][40] = crs[j][38]+crs[j][39]; // NCgamma
                crs[j][51] = crssect[j][51]*num_of_p; // NEUBAR,P -> NEUBAR,P
                crs[j][52] = crssect[j][52]*num_of_n; // NEUBAR,N -> NEUBAR,N
                crs[j][53] = crs[j][51]+crs[j][52]; // NCEL
                // [58] -> CCTOT
                crs[j][58] = crs[j][1]+crs[j][2]+crs[j][14]+crs[j][16]+crs[j][17] // QE, MEC, 1PI, COH, 1gamma
                                 //+ crssect[j][18]*num_of_n + crssect[j][19]*num_of_n + crssect[j][20]*num_of_n // 1K
                                 + crs[j][21] + crssect[j][22]*num_of_n + crssect[j][23]*num_of_n // MPI, 1ETA, 1K
                                 + crs[j][26]; // DIS
                // [59] -> NCTOT
                crs[j][59] = crs[j][30] + crs[j][36] + crs[j][40] + crs[j][41]  // 1PI, COH, 1gamma, MPI
                                + crssect[j][42]*num_of_n + crssect[j][43]*num_of_p // 1ETA
                                + crssect[j][44]*num_of_n + crssect[j][45]*num_of_p // 1K
                                + crs[j][46] + crs[j][53]; // DIS, EL
            }
    

            // sigma/E
            r_crs[j][0]  = (float) crs[j][0]/enu;
            r_crs[j][1]  = (float) crs[j][1]/enu;
            r_crs[j][2]  = (float) crs[j][2]/enu;
            r_crs[j][14] = (float) crs[j][14]/enu;
            r_crs[j][16] = (float) crs[j][16]/enu; 
            r_crs[j][17] = (float) crs[j][17]/enu; 
            r_crs[j][21] = (float) crs[j][21]/enu; 
            r_crs[j][26] = (float) crs[j][26]/enu; 
            r_crs[j][30] = (float) crs[j][30]/enu; 
            r_crs[j][36] = (float) crs[j][36]/enu; 
            r_crs[j][40] = (float) crs[j][40]/enu; 
            r_crs[j][41] = (float) crs[j][41]/enu; 
            r_crs[j][46] = (float) crs[j][46]/enu; 
            r_crs[j][53] = (float) crs[j][53]/enu; 
            r_crs[j][58] = (float) crs[j][58]/enu; 
            r_crs[j][59] = (float) crs[j][59]/enu; 
            r_crs[j][51] = (float) crs[j][51]/enu; 
            r_crs[j][52] = (float) crs[j][52]/enu; 

            e_c[j]->SetPoint(index[j],enu,crs[j][0]);
            e_c_cc[j]->SetPoint(index[j],enu,crs[j][58]); // CCTOT
            e_c_nc[j]->SetPoint(index[j],enu,crs[j][59]); // NCTOT
            e_c_ccqe[j]->SetPoint(index[j],enu,crs[j][1]);
            e_c_ccmec[j]->SetPoint(index[j],enu,crs[j][2]);
            e_c_cc1pi[j]->SetPoint(index[j],enu,crs[j][14]);
            e_c_cccoh[j]->SetPoint(index[j],enu,crs[j][16]);
            e_c_ccgamma[j]->SetPoint(index[j],enu,crs[j][17]);
            e_c_ccmpi[j]->SetPoint(index[j],enu,crs[j][21]);
            e_c_ccdis[j]->SetPoint(index[j],enu,crs[j][26]);
            e_c_nc1pi[j]->SetPoint(index[j],enu,crs[j][30]);
            e_c_nccoh[j]->SetPoint(index[j],enu,crs[j][36]);
            e_c_ncgamma[j]->SetPoint(index[j],enu,crs[j][40]);
            e_c_ncmpi[j]->SetPoint(index[j],enu,crs[j][41]);
            e_c_ncdis[j]->SetPoint(index[j],enu,crs[j][46]);
            e_c_ncel[j]->SetPoint(index[j],enu,crs[j][53]);
            e_c_ncel_p[j]->SetPoint(index[j],enu,crs[j][51]);
            e_c_ncel_n[j]->SetPoint(index[j],enu,crs[j][52]);
            // r_
            r_e_c[j]->SetPoint(index[j],enu,r_crs[j][0]);
            r_e_c_cc[j]->SetPoint(index[j],enu,r_crs[j][58]);
            r_e_c_nc[j]->SetPoint(index[j],enu,r_crs[j][59]);
            r_e_c_ccqe[j]->SetPoint(index[j],enu,r_crs[j][1]);
            r_e_c_ccmec[j]->SetPoint(index[j],enu,r_crs[j][2]);
            r_e_c_cc1pi[j]->SetPoint(index[j],enu,r_crs[j][14]);
            r_e_c_cccoh[j]->SetPoint(index[j],enu,r_crs[j][16]);
            r_e_c_ccgamma[j]->SetPoint(index[j],enu,r_crs[j][17]);
            r_e_c_ccmpi[j]->SetPoint(index[j],enu,r_crs[j][21]);
            r_e_c_ccdis[j]->SetPoint(index[j],enu,r_crs[j][26]);
            r_e_c_nc1pi[j]->SetPoint(index[j],enu,r_crs[j][30]);
            r_e_c_nccoh[j]->SetPoint(index[j],enu,r_crs[j][36]);
            r_e_c_ncgamma[j]->SetPoint(index[j],enu,r_crs[j][40]);
            r_e_c_ncmpi[j]->SetPoint(index[j],enu,r_crs[j][41]);
            r_e_c_ncdis[j]->SetPoint(index[j],enu,r_crs[j][46]);
            r_e_c_ncel[j]->SetPoint(index[j],enu,r_crs[j][53]);
            r_e_c_ncel_p[j]->SetPoint(index[j],enu,r_crs[j][51]);
            r_e_c_ncel_n[j]->SetPoint(index[j],enu,r_crs[j][52]);
            index[j]++;
            //if(j==0 && enu<=10) std::cout << std::setw(5) << enu << " " << std::setw(5) << crs[j][0] << std::endl;
        }
    }

    TCanvas* c0 = new TCanvas("c0","c0",0,0,900,600);
    c0->Divide(3,2);
    TH1F* waku[6];
    TLatex* tx[6];
    for(int i=0;i<6;i++){
        c0->cd(i+1);
        gPad->SetLeftMargin(0.15);
        gPad->SetRightMargin(0.05);
        gPad->SetBottomMargin(0.11);
        waku[i] = gPad->DrawFrame(0,0.01,2,500);
        // Color
        e_c_cc[i]->SetLineColor(kRed);
        e_c_nc[i]->SetLineColor(kRed);
        e_c_ccqe[i]->SetLineColor(kBlue);
        e_c_ccmec[i]->SetLineColor(kGreen);
        e_c_cc1pi[i]->SetLineColor(kCyan);
        e_c_cccoh[i]->SetLineColor(kGreen);
        e_c_ccgamma[i]->SetLineColor(kOrange);
        e_c_ccmpi[i]->SetLineColor(30);
        e_c_ccdis[i]->SetLineColor(kMagenta);
        e_c_nc1pi[i]->SetLineColor(kCyan);
        e_c_nccoh[i]->SetLineColor(kGreen);
        e_c_ncgamma[i]->SetLineColor(kOrange);
        e_c_ncmpi[i]->SetLineColor(30);
        e_c_ncdis[i]->SetLineColor(kMagenta);
        e_c_ncel[i]->SetLineColor(kBlue);
        //
        e_c_cc[i]->SetLineWidth(2);
        e_c_nc[i]->SetLineWidth(2);
        e_c_ccqe[i]->SetLineWidth(2);
        e_c_ccmec[i]->SetLineWidth(2);
        e_c_cc1pi[i]->SetLineWidth(2);
        e_c_cccoh[i]->SetLineWidth(2);
        e_c_ccgamma[i]->SetLineWidth(2);
        e_c_ccmpi[i]->SetLineWidth(2);
        e_c_ccdis[i]->SetLineWidth(2);
        e_c_nc1pi[i]->SetLineWidth(2);
        e_c_nccoh[i]->SetLineWidth(2);
        e_c_ncgamma[i]->SetLineWidth(2);
        e_c_ncmpi[i]->SetLineWidth(2);
        e_c_ncdis[i]->SetLineWidth(2);
        e_c_ncel[i]->SetLineWidth(2);
        // Style
        e_c_nc[i]->SetLineStyle(2);
        e_c_nc1pi[i]->SetLineStyle(2);
        e_c_nccoh[i]->SetLineStyle(2);
        e_c_ncgamma[i]->SetLineStyle(2);
        e_c_ncmpi[i]->SetLineStyle(2);
        e_c_ncdis[i]->SetLineStyle(2);
        e_c_ncel[i]->SetLineStyle(2);
        // Draw
        e_c[i]->Draw("Lsame");
        e_c_cc[i]->Draw("Lsame");
        e_c_nc[i]->Draw("Lsame");
        e_c_ccqe[i]->Draw("Lsame");
        e_c_ccmec[i]->Draw("Lsame");
        e_c_cc1pi[i]->Draw("Lsame");
        //e_c_cccoh[i]->Draw("Lsame");
        //e_c_ccgamma[i]->Draw("Lsame");
        e_c_ccmpi[i]->Draw("Lsame");
        e_c_ccdis[i]->Draw("Lsame");
        e_c_nc1pi[i]->Draw("Lsame");
        //e_c_nccoh[i]->Draw("Lsame");
        //e_c_ncgamma[i]->Draw("Lsame");
        e_c_ncmpi[i]->Draw("Lsame");
        e_c_ncdis[i]->Draw("Lsame");
        e_c_ncel[i]->Draw("Lsame");
        //
        waku[i]->SetTitle(nuname[i]);
        waku[i]->GetXaxis()->SetTitle("E_{#nu} [GeV]");
        waku[i]->GetXaxis()->SetTitleSize(0.05);
        os.str("");
        os << "#sigma_{" << target.str() << "} [10^{-38}cm^{2}]";
	      waku[i]->GetYaxis()->SetTitle(os.str().c_str());
        waku[i]->GetYaxis()->SetTitleSize(0.05);
        waku[i]->GetYaxis()->SetTitleOffset(1.2);
        tx[i]=new TLatex(1,100,nuname[i]);
        tx[i]->SetTextColor(6);
        tx[i]->SetTextSize(0.08);
        //tx[i]->Draw();
        gPad->SetLogy();
    }


    TCanvas* c1 = new TCanvas("c1","c1",50,50,900,600);
    c1->Divide(3,2);
    TH1F* waku1[6];
    TLatex* tx1[6];
    TLine* line[6];
    for(int i=0;i<6;i++){
        c1->cd(i+1);
        gPad->SetLeftMargin(0.15);
        gPad->SetRightMargin(0.05);
        //gPad->SetTopMargin(0.1);
        gPad->SetBottomMargin(0.11);
        if(i<=2) waku1[i] = gPad->DrawFrame(0,0,3,25);
        else     waku1[i] = gPad->DrawFrame(0,0,3,10);
        //if(i<=2) waku1[i] = gPad->DrawFrame(0,0,1e4,18);
        //else     waku1[i] = gPad->DrawFrame(0,0,1e4,7);
        // Color
        r_e_c_cc[i]->SetLineColor(kRed);
        r_e_c_nc[i]->SetLineColor(kRed);
        r_e_c_ccqe[i]->SetLineColor(kBlue);
        r_e_c_ccmec[i]->SetLineColor(kGreen);
        r_e_c_cc1pi[i]->SetLineColor(kCyan);
        r_e_c_cccoh[i]->SetLineColor(kGreen);
        r_e_c_ccgamma[i]->SetLineColor(kOrange);
        r_e_c_ccmpi[i]->SetLineColor(30);
        r_e_c_ccdis[i]->SetLineColor(kMagenta);
        r_e_c_nc1pi[i]->SetLineColor(kCyan);
        r_e_c_nccoh[i]->SetLineColor(kGreen);
        r_e_c_ncgamma[i]->SetLineColor(kOrange);
        r_e_c_ncmpi[i]->SetLineColor(30);
        r_e_c_ncdis[i]->SetLineColor(kMagenta);
        r_e_c_ncel[i]->SetLineColor(kBlue);
        // Width
        r_e_c[i]->SetLineWidth(2);
        r_e_c_cc[i]->SetLineWidth(2);
        r_e_c_nc[i]->SetLineWidth(2);
        r_e_c_ccqe[i]->SetLineWidth(2);
        r_e_c_ccmec[i]->SetLineWidth(2);
        r_e_c_cc1pi[i]->SetLineWidth(2);
        r_e_c_cccoh[i]->SetLineWidth(2);
        r_e_c_ccgamma[i]->SetLineWidth(2);
        r_e_c_ccmpi[i]->SetLineWidth(2);
        r_e_c_ccdis[i]->SetLineWidth(2);
        r_e_c_nc1pi[i]->SetLineWidth(2);
        r_e_c_nccoh[i]->SetLineWidth(2);
        r_e_c_ncgamma[i]->SetLineWidth(2);
        r_e_c_ncmpi[i]->SetLineWidth(2);
        r_e_c_ncdis[i]->SetLineWidth(2);
        r_e_c_ncel[i]->SetLineWidth(2);
        // Style
        r_e_c_nc[i]->SetLineStyle(2);
        r_e_c_nc1pi[i]->SetLineStyle(2);
        r_e_c_nccoh[i]->SetLineStyle(2);
        r_e_c_ncgamma[i]->SetLineStyle(2);
        r_e_c_ncmpi[i]->SetLineStyle(2);
        r_e_c_ncdis[i]->SetLineStyle(2);
        r_e_c_ncel[i]->SetLineStyle(2);
        // Draw
        r_e_c[i]->Draw("Lsame");
        r_e_c_cc[i]->Draw("Lsame");
        r_e_c_nc[i]->Draw("Lsame");
        r_e_c_ccqe[i]->Draw("Lsame");
        r_e_c_ccmec[i]->Draw("Lsame");
        r_e_c_cc1pi[i]->Draw("Lsame");
        //r_e_c_cccoh[i]->Draw("Lsame");
        //r_e_c_ccgamma[i]->Draw("Lsame");
        r_e_c_ccmpi[i]->Draw("Lsame");
        r_e_c_ccdis[i]->Draw("Lsame");
        r_e_c_nc1pi[i]->Draw("Lsame");
        //r_e_c_nccoh[i]->Draw("Lsame");
        //r_e_c_ncgamma[i]->Draw("Lsame");
        r_e_c_ncmpi[i]->Draw("Lsame");
        r_e_c_ncdis[i]->Draw("Lsame");
        r_e_c_ncel[i]->Draw("Lsame");
        // 
        waku1[i]->SetTitle(nuname[i]);
        waku1[i]->SetTitleSize(0.05);
        waku1[i]->GetXaxis()->SetTitle("E_{#nu} [GeV]");
        waku1[i]->GetXaxis()->SetTitleSize(0.05);
        os.str("");
        os << "#sigma_{" << target.str() << "}/E_{#nu} [10^{-38}cm^{2}/GeV]";
	      waku1[i]->GetYaxis()->SetTitle(os.str().c_str());
        waku1[i]->GetYaxis()->SetTitleSize(0.05);
        waku1[i]->GetYaxis()->SetTitleOffset(1.1);
        tx1[i]=new TLatex(4,1.2,nuname[i]);
        tx1[i]->SetTextColor(6);
        tx1[i]->SetTextSize(0.08);
        //tx1[i]->Draw("same");
        //if(i<=2) line[i]=new TLine(0.6,0,0.6,20);
        if(i<=2) line[i]=new TLine(0.6,0,0.6,18);
        else     line[i]=new TLine(0.6,0,0.6,7);

        line[i]->SetLineStyle(2);
        //line[i]->Draw("same");
        
    }






    return 0;
}
